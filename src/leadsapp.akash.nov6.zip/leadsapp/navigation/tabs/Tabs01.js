import React from 'react'
import styled from 'styled-components'

export default function Tabs01() {
	return (
		<StyledDiv01>
			<h1>Tabs01</h1>
		</StyledDiv01>
	)
}

const StyledDiv01 = styled.div`

`