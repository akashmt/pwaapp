export const BORDER_RADIUS = '4px'

export const BOX_SHADOW = '0px 1px 1px 0px rgba(0, 0, 0, 0.2)'
