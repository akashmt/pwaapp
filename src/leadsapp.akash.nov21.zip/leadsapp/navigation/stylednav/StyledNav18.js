import React from 'react'
import styled from 'styled-components'
// Source: 

export default function StyledNav18() {
	return (
		<StyledDiv18 className="Screen">

		</StyledDiv18>
	)
}

const StyledDiv18 = styled.div`

`