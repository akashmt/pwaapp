import React from 'react'
import styled from 'styled-components'
import { PRIMARY_COLOR, PRIMARY_SHADE, PRIMARY_TINT,
				 SECONDARY_COLOR, SECONDARY_SHADE, SECONDARY_TINT,
				 MEDIUM_COLOR, MEDIUM_SHADE, MEDIUM_TINT,
         LIGHT_COLOR, LIGHT_SHADE } from '../../_consts'

import FirebaseContext from "../../../firebase/context"
import LeadItem from './LeadItem'


export default function RoleBasedLeadList(props) {
  const { user,firebase } = React.useContext(FirebaseContext)
  const [ leads, setLeads ] = React.useState([])
  const [ loading, setLoading ] = React.useState(false)
  const [ userInfo, setUserInfo ] = React.useState({})
  const userRef = firebase.db.collection('users').doc(user.uid)
  let leadRef
  if(userInfo.role && userInfo.role !== null) {
    leadRef = firebase.db.collection('links').where('postedBy.rid', '>=', userInfo.role.id)
  }
  
 
  React.useEffect(() => {
    getUserInfo()
  }, [])

  function getUserInfo() {
    userRef.get().then(doc => {
      setUserInfo({ ...doc.data(), id: doc.id })
    })
  }

  React.useEffect(() => {
		const unsubscribe = getRoleBasedLeads()
		return () => unsubscribe()
  }, [userInfo])

 
  function getRoleBasedLeads() {
    setLoading(true)
    if(leadRef && leadRef !== null) {
      leadRef
      .onSnapshot(handleSnapshot)
    }
    return () => {}
  }
  
  function handleSnapshot(snapshot) {
		const leads = snapshot.docs.map(doc => {
			return { id: doc.id, ...doc.data() }
    })
		setLeads(leads)
    setLoading(false)
    console.log(leads)
  }
 
  return (
    <StyledSection style={{ opacity: loading ? 0.25 : 1 }}>
      <h2>Role Based Leads - {userInfo.role && userInfo.role.name}</h2>
      {leads.map((link, index) => {
        return ( 
          <LeadItem 	
            key={link.id}
            showCount={true}
            lead={link}
            index={index+1} /> 
        )
      })}
    </StyledSection>
  )
  
 
}
const StyledSection = styled.section`
	margin: 0px;
	padding: 0px;
	/* background: white; */
	/* border: ${SECONDARY_SHADE}; */
	h2 {
		margin-bottom: 30px;
		text-align: center;
		color: #232323;
		/* color: ${MEDIUM_COLOR}; */
	}
`