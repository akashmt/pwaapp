import { createGlobalStyle  }  from 'styled-components';

export const Buttons = createGlobalStyle `

`