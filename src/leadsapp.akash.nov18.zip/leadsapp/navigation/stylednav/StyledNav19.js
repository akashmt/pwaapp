import React from 'react'
import styled from 'styled-components'
// Source: 

export default function StyledNav19() {
	return (
		<StyledDiv19 className="Screen">

		</StyledDiv19>
	)
}

const StyledDiv19 = styled.div`

`