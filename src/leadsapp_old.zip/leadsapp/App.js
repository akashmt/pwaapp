import React from 'react'
import { BrowserRouter as Router } from 'react-router-dom'
import AppStyles from './styles/global'

import useAuth from './components/Auth/useAuth'
import firebase, { FirebaseContext } from '../firebase'

import Header from './components/Header'
import Main from './components/Main'

function App() {
	const user = useAuth()
	return (
		<Router>
		<FirebaseContext.Provider value={{ user, firebase }}>
		<div className="App">
			<AppStyles/>
			<Header/>
			<Main/>
		</div>
		</FirebaseContext.Provider>
		</Router>
	)
}

export default App
