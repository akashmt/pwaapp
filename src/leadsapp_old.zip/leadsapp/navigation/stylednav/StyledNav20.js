import React from 'react'
import styled from 'styled-components'
// Source: 

export default function StyledNav20() {
	return (
		<StyledDiv20 className="Screen">

		</StyledDiv20>
	)
}

const StyledDiv20 = styled.div`

`