import React from 'react'
import { withRouter, NavLink } from 'react-router-dom'
import styled from 'styled-components'
import { FirebaseContext } from '../../firebase'

function Header() {
	const { user, firebase } = React.useContext(FirebaseContext)
	return (
		<StyledHeader className="App-header">
			<figure className="Header-brand">
				<img src="/logo.png" alt="Leads Logo" />
				<NavLink to="/leadsapp/">Hooks Leads</NavLink>
			</figure>

			<nav className="Header-navigation">
				<ul>
					<li><NavLink to="/leadsapp/">new</NavLink></li>
					<li><NavLink to="/leadsapp/top">top</NavLink></li>
					<li><NavLink to="/leadsapp/search">search</NavLink></li>
					{user && (
						<li><NavLink to="/leadsapp/create">submit</NavLink></li>
					)}
				</ul>
			</nav>

			<section className="Header-usernav">
				<ul>
					<li><NavLink to="/leadsapp/dashboard">dashboard</NavLink></li>
					{user ? (
						<>
						<li>
							<figure>
								<img src="https://via.placeholder.com/150" alt="profile image" />
								<p>{user.displayName}</p>
							</figure>
						</li>
						<li>
							<span>
								<button onClick={() => firebase.logout()}>logout</button>
							</span>
						</li>
						</>
					) : (
						<li><NavLink to="/leadsapp/login">login</NavLink></li>
					)}	
				</ul>
			</section>
		</StyledHeader>
	)
}

export default withRouter(Header)

const StyledHeader = styled.header`
	display: grid;
	grid-template-columns: 1fr;
	grid-template-areas:
		"appbrand"
		"appnav"
		"appuser";
	figure.Header-brand 		{ grid-area: appbrand; }
	nav.Header-navigation 	{ grid-area: appnav; }
	section.Header-usernav 	{ grid-area: appuser; }

	margin: 0px 0px 0px 0px;

	figure.Header-brand {
		display: flex;
		flex-direction: row;
		justify-content: flex-start;
		flex-wrap: nowrap; 
		align-items: center;
		align-content: center;
		margin: 0px; padding: 15px; 
		background-color: blue;
		img { 
			margin: 0px 15px 0px 0px; padding:0px; 
			width: 45px; height: 45px;
		}
		a {
			text-decoration: none;
			font-size: 1.4rem;
			font-weight: bold;
			color: white;
			&:hover {
				color: grey;
			}
		}
	}
	nav.Header-navigation  {
		margin: 0px; padding: 20px 15px 20px 15px; 
		background-color: blue;
		ul {
			display: flex;
			flex-direction: row;
			justify-content: space-between;
			flex-wrap: nowrap; 
			align-items: center;
			align-content: center;
			list-style: none;
			li { 
				a {
					padding: 10px 12px;
					color: white;
					text-decoration: none;
					text-transform: uppercase;
					font-weight: bold;
					font-size: .8rem;
					background-color: grey;
					&:hover { color: black; }
				}
			}
		}
	}
	section.Header-usernav  {
		margin: 0px 0px 15px 0px; padding: 10px 15px 10px 15px;
		background-color: #f1f1f1;
		border-top: 1px solid #232323;
		ul {
			display: flex;
			flex-direction: row;
			justify-content: space-between;
			flex-wrap: nowrap; 
			align-items: center;
			align-content: center;

			margin: 0px; padding:0px; 
			list-style: none;
			li { 
				margin-right: 30px;
				&:last-of-type { margin-right: 0px; }
				a { }
				figure {
					display: flex;
					flex-direction: row;
					justify-content: flex-start;
					flex-wrap: nowrap; 
					align-items: center;
					align-content: center;
					margin: 0px;
					img {
						margin-right: 5px;
						max-width: 40px; max-height: 40px;
						border-radius: 50%;
					}
					p {
						padding: 4px 3px;
					}
				}
				span {
					button {
						margin: 0px; padding: 6px 10px;
						border: 0px;
						text-transform: capitalize;
					}
				}
			}
		}
	}
`