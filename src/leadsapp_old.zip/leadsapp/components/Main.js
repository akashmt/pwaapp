import React from 'react'
import { Switch, Route, Redirect } from 'react-router-dom'
import styled from 'styled-components'

import Login from './Auth/Login'

import ForgotPassword from './Auth/ForgotPassword'
import CreateLink from './Link/CreateLink'
import SearchLinks from './Link/SearchLinks'
import LinkList from './Link/LinkList'
import LinkDetail from './Link/LinkDetail'

function Main() {
	return (
		<StyledMain className="route-container">
			<Switch>
				<Route exact path="/leadsapp/" render={() => <Redirect to="/leadsapp/new/1" />} />
				{/* <Route exact path="/" component={Login} /> */}
				<Route path="/leadsapp/create" component={CreateLink} />
				<Route path="/leadsapp/login" component={Login} />
				<Route path="/leadsapp/forgot" component={ForgotPassword} />
				<Route path="/leadsapp/search" component={SearchLinks} />
				<Route path="/leadsapp/top" component={LinkList} />
				<Route path="/leadsapp/new/:page" component={LinkList} />
				<Route path="/leadsapp/link/:linkId" component={LinkDetail} />
			</Switch>
		</StyledMain>
	)
}

export default Main

const StyledMain = styled.main`
	padding: 15px;
`